Ol�, para testar o c�digo n�s temos dois arquivos de texto na pasta Arquivos. Um deles � o Itens, no qual adicionamos os
itens na lista, no seguinte formato: nome, pre�o, quantidade. Os dados s�o separados por v�rgula e cada novo item � uma 
nova linha. O outro arquivo � o Emails no qual adicionamos os emails, onde cada linha representa um novo email. Ambos os
arquivos j� possuem uma exemplifica��o de como os dados devem ser descritos. Ap�s ajustar os dados de imput nos arquivos,
basta apenas executar o arquivo Principal. Vale ressaltar que o resultado est� em centavos e que para testar uma
lista vazia basta salvar os arquivos desejados sem conte�do.